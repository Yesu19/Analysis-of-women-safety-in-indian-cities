from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor
import joblib
import pandas as pd

# Load the dataset
data = pd.read_csv('MeToo_tweets.csv')

# Selecting the 'Source' and 'Retweet_count' columns as features and target respectively
X = data[['Source']]
y = data['Retweet_count']

# Encoding the 'Source' column as it is categorical
label_encoder = LabelEncoder()
X_encoded = label_encoder.fit_transform(X['Source']).reshape(-1, 1)

# Splitting the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_encoded, y, test_size=0.2, random_state=42)

# Define the XGBoost regressor with reduced complexity
xgb_regressor = XGBRegressor(n_estimators=50, max_depth=3, learning_rate=0.1, random_state=42)

# Train the XGBoost regressor on the training data
xgb_regressor.fit(X_train, y_train)

# Save the trained model to disk
model_filename = 'xgb_meToo_tweets_model.joblib'
joblib.dump(xgb_regressor, model_filename)

print(f"Model saved successfully at {model_filename}")
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error

# Predictions
y_train_pred = xgb_regressor.predict(X_train)
y_test_pred = xgb_regressor.predict(X_test)

# Calculate MSE for both training and testing sets
mse_train = mean_squared_error(y_train, y_train_pred)
mse_test = mean_squared_error(y_test, y_test_pred)

# Plotting the MSE values
plt.figure(figsize=(10, 6))
plt.bar(['Train MSE', 'Test MSE'], [mse_train, mse_test], color=['blue', 'green'])
plt.title('Model Performance: Mean Squared Error')
plt.ylabel('Mean Squared Error')
plt.show()
