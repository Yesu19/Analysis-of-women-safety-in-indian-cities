import nltk
nltk.download()
